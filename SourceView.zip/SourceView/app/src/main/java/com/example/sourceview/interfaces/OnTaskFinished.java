package com.example.sourceview.interfaces;

public interface OnTaskFinished
{
    public void onFeedRetrieved(String feeds);
}